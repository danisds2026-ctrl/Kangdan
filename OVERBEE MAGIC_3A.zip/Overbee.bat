@echo off
title OVERBEE CLOUD UNLOCKER
color 0F
echo =============================================
echo      OVERBEE KING'S FINAL BYPASS TOOL
echo =============================================
echo.

:: ============ MATIKAN IDLE 24 JAM ============
echo [*] Matikan idle, sleep, dan screensaver...
powercfg -change -monitor-timeout-ac 0 >nul 2>&1
powercfg -change -monitor-timeout-dc 0 >nul 2>&1
powercfg -change -standby-timeout-ac 0 >nul 2>&1
powercfg -change -standby-timeout-dc 0 >nul 2>&1
powercfg -change -hibernate-timeout-ac 0 >nul 2>&1
powercfg -change -hibernate-timeout-dc 0 >nul 2>&1

:: ============ UNLOCK TASKBAR ============
echo [*] Memaksa taskbar muncul...
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v TaskbarAutoHide /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v NoTaskbar /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v NoTaskbar /t REG_DWORD /d 0 /f >nul 2>&1

:: ============ UNLOCK SETTINGS ============
echo [*] Membuka akses Control Panel & Settings...
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v NoControlPanel /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v NoControlPanel /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\System" /v DisableRegistryTools /t REG_DWORD /d 0 /f >nul 2>&1

:: ============ RESTART EXPLORER (biar efek langsung) ============
echo [*] Restart explorer...
taskkill /f /im explorer.exe >nul 2>&1
start explorer.exe

:: ============ BUKA SETTINGS ============
echo [*] Buka Settings & Control Panel...
start control.exe
start ms-settings:

:: ============ KEEP-ALIVE BACKGROUND ============
echo [*] Menjalankan keep-alive 24 jam di background...
start /min powershell -windowstyle hidden -command "while($true){Start-Sleep -Seconds 180; $wsh=New-Object -ComObject WScript.Shell; $wsh.SendKeys('{F15}')}"

echo.
echo =============================================
echo  [+] SELESAI! Cek layar PC/Cloud elu!
echo  [+] 1. Layar TIDAK AKAN MATI 24 JAM!
echo  [+] 2. Taskbar SUDAH MUNCUL!
echo  [+] 3. Settings & Control Panel BISA DIBUKA!
echo  [+] 4. Keep-alive berjalan di background!
echo =============================================
echo.
pause
