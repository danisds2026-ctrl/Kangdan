@echo off
title [OVERBEE] Tencent Cloud Bypass Tool
color 0A
echo ==============================================
echo     OVERBEE CLOUD UNLOCKER v1.0 - VVIP MODE
echo ==============================================
echo.

:: [1] MATIIN IDLE TIMEOUT & SCREEN SAVER
echo [*] Mematikan idle timeout & screensaver...
powercfg -change -monitor-timeout-ac 0
powercfg -change -monitor-timeout-dc 0
powercfg -change -standby-timeout-ac 0
powercfg -change -standby-timeout-dc 0
powercfg -change -hibernate-timeout-ac 0
powercfg -change -hibernate-timeout-dc 0
reg add "HKCU\Control Panel\Desktop" /v ScreenSaveActive /t REG_SZ /d 0 /f
reg add "HKCU\Control Panel\Desktop" /v ScreenSaveTimeOut /t REG_SZ /d 0 /f

:: [2] BYPASS TASKBAR HIDE POLICY (Force Show Taskbar)
echo [*] Memaksa Taskbar muncul...
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v TaskbarAutoHide /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v NoTaskbar /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v NoTaskbar /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v DisableTaskMgr /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\System" /v DisableTaskMgr /t REG_DWORD /d 0 /f
taskkill /f /im explorer.exe
start explorer.exe

:: [3] UNLOCK FULL CONTROL PANEL & SETTINGS (Bypass Group Policy)
echo [*] Membuka akses penuh ke Pengaturan & Control Panel...
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v NoControlPanel /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v NoControlPanel /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\System" /v NoDispSettingsPage /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v NoDispSettingsPage /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Policies\Microsoft\MMC" /v RestrictToPermittedSnapins /t REG_DWORD /d 0 /f
reg add "HKLM\Software\Policies\Microsoft\MMC" /v RestrictToPermittedSnapins /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v NoFolderOptions /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v NoFolderOptions /t REG_DWORD /d 0 /f

:: [4] UNLOCK REGISTRY EDITOR & CMD (Kalo di-lock sama admin)
echo [*] Unlock Registry Editor & CMD...
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\System" /v DisableRegistryTools /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v DisableRegistryTools /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Policies\Microsoft\Windows\System" /v DisableCMD /t REG_DWORD /d 0 /f
reg add "HKLM\Software\Policies\Microsoft\Windows\System" /v DisableCMD /t REG_DWORD /d 0 /f

:: [5] KILL PROSES MONITORING TENANT (Nge-kill proses monitoring biar gak ketauan)
echo [*] Mematikan proses monitoring Tencent (optional)...
taskkill /f /im qqcloudmonitor.exe 2>nul
taskkill /f /im tencentdl.exe 2>nul
taskkill /f /im qmbsvc.exe 2>nul
taskkill /f /im TBS*.exe 2>nul

:: [6] RESTART EXPLORER & BIARIN PC ON 24 JAM (Loop Keep-Alive)
echo [*] Menyiapkan Loop Keep-Alive 24 Jam (Minimize window ini biar gak ganggu)...
:loop
timeout /t 300 /nobreak >nul
:: Keep session active dengan mensimulasi aktivitas keyboard (F15 biar gak ganggu)
powershell -command "$wsh = New-Object -ComObject WScript.Shell; $wsh.SendKeys('{F15}')"
taskkill /f /im explorer.exe 2>nul
start explorer.exe
goto loop
